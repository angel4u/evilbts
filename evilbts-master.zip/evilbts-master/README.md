# EvilBTS

This repository contains Yate and YateBTS specific versions ( plus patches ) that are working with the BladeRF.
